﻿Nekoliko napomena uz datoteku HR_Txt-601.txt:

Datoteka HR_Txt-601.txt ima 601.244 zapisa i predstavlja iscrpan popis riječi hrvatskog jezika. Zapisana je korištenjem kodiranja UTF-8.

Sastoji se od 4 stupca međusobno odvojenih tabulatorom
 1) Kosi oblik
 2) Osnovni oblik
 3) Oznake
 4) Vrsta riječi
 

O tome što je ova datoteka i zbog čega je nastala možete pročitati na adresi 
    http://www.igaly.org/rjecnik-hrvatskih-jezika

Tumačenje oznaka iz trećeg stupca ove datoteke nalazi se na stranici 
    http://www.igaly.org/rjecnik-hrvatskih-jezika/pages/znacenje-oznaka.php

Datoteku možete slobodno i bez naknade koristiti u sve nekomercijalne i istraživačke svrhe, uz obavezno navođenje izvora podataka i autora. 
Ako datoteku koristite u komercijalne svrhe, bilo bi lijepo da dio zarade uložite u razvoj ovog projekta.
Ako želite svojom donacijom potaknuti daljnji razvoj rječnika, kontaktirajte me na igaly@math.hr i dat ću vam podatke za uplatu putem PayPala.
Korištenje ove datoteke na web stranicama koje objavljuju Google oglase nije dozvoljeno ni na koji način bez izričite dozvole autora.

Molim vas da me obavijestite o načinu na koji ste iskoristili ili namjeravate koristiti datoteku HR.Txt

Također vas molim da mi pošaljete riječi kojih nema u ovoj datoteci, a za koje smatrate da pripadaju hrvatskom jeziku.

Zahvaljujem se kolegi Anti Poceduliću na pomoći u pripremi ovog rječnika.


-  -  -  o  o  o  -  -  -

I na kraju.....

Ovaj rječnik hrvatskih jezika je dio većeg projekta koji u sebi sadrži dva jednojezična rječnika - hrvatski i engleski, te dvojezični hrvatsko-engleski rječnik EH.Txt.
EH.Txt je najpopularniji i najveći otvoreni hrvatsko-engleski rječnik, dostupan za preuzimanje od 2002. godine. 
Molim vas da svojim potpisom i angažmanom poognete u prikupljanju 20.000 potpisa potrebnih za objavu EH.Txt, verzija 2.05 koja je pripremljena u rujnu 2009. godine.
    http://www.igaly.org/rjecnik-hrvatskih-jezika/pages/eh.txt-2.05.php



dr. Goran Igaly, autor i urednik HR.Txt i EH.Txt
igaly@math.hr



U Zagrebu, 12. ožujka 2014.